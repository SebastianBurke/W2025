use("scanalesburke_db")
const bulk = db.employees.initializeUnorderedBulkOp();
